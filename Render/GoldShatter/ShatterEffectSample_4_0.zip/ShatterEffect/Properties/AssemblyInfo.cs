﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Shatter Effect")]
[assembly: AssemblyProduct("Shatter Effect")]
[assembly: AssemblyDescription("This sample shows how you can apply an effect on any model in your game to shatter it apart. The effect is simulated with a vertex shader.")]
[assembly: AssemblyCompany("Microsoft")]

[assembly: AssemblyCopyright("Copyright © Microsoft")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("03d7db13-4eaa-4b90-b6a4-32c11aa0a3d5")]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
