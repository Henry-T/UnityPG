

#import "cocos2d.h"
#import <spine/spine-cocos2d-iphone.h>

@interface SpineboyExample : CCNode {
	SkeletonAnimation* skeletonNode;
}

+ (CCScene*) scene;

@end