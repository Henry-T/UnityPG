# Spine Runtimes

This project hosts the runtimes needed to use [Spine](http://esotericsoftware.com/) 2D skeletal animations with various game toolkits.

The code provided here is currently under development and is subject to change.

Documentation is being worked on and will be provided as soon as possible.