

#import "cocos2d.h"
#import <spine/spine-cocos2d-iphone.h>

@interface GoblinsExample : CCNode {
	SkeletonAnimation* skeletonNode;
}

+ (CCScene*) scene;

@end